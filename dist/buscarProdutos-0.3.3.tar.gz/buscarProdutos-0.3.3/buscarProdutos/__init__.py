from .buscarNaMagalu import *
from .buscarNoMercadoLivre import *
